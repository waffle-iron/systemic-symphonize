symphonize
============

This project is a client library for the Orchestrate.io services. Check out http://orchestrate.io/ for more information on those services. For more information on the library ping me [@adron](https://github.com/Adron) on github or [@adron](https://twitter.com/Adron) on Twitter.

##### Sym´pho`nize
<blockquote>v. i.	1. To agree; to be in harmony.</br>
[imp. & p. p. Symphonized ; p. pr. & vb. n. Symphonizing .]</blockquote>
<b><i>Webster's Revised Unabridged Dictionary</b></i>, published 1913 by C. & G. Merriam Co.

For a project of working examples, check out [Symponize Integration Samples](https://github.com/Adron/symphonize_integration_samples).