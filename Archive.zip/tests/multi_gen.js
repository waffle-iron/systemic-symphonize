/**
 * Created by adron on 12/30/13.
 * Description: Tests for the multi_gen code.
 */
