/**
 * Created by adron on 12/30/13.
 * Description: Tests for the symphonize project.
 */

// Verify tests are running because: people forget.
var assert = require("assert")

describe('Test Framework', function () {
    describe('mocha', function () {
        it('should be installed and running.', function () {
            assert.equal(true, true);
        })
    })
})